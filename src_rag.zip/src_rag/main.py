import evaluate
import models

evaluate.run_evaluate_retrieval(config={
    "model": {}
})
evaluate.run_evaluate_reply(config={
    "model": {}
})
